package mooc.vandy.java4android.diamonds.logic;

import mooc.vandy.java4android.diamonds.ui.OutputInterface;

/**
 * This is where the logic of this App is centralized for this assignment.
 * <p>
 * The assignments are designed this way to simplify your early
 * Android interactions.  Designing the assignments this way allows
 * you to first learn key 'Java' features without having to beforehand
 * learn the complexities of Android.
 */
public class Logic
       implements LogicInterface {
    /**
     * This is a String to be used in Logging (if/when you decide you
     * need it for debugging).
     */
    public static final String TAG = Logic.class.getName();

    /**
     * This is the variable that stores our OutputInterface instance.
     * <p>
     * This is how we will interact with the User Interface [MainActivity.java].
     * <p>
     * It is called 'out' because it is where we 'out-put' our
     * results. (It is also the 'in-put' from where we get values
     * from, but it only needs 1 name, and 'out' is good enough).
     */
    private OutputInterface mOut;

    /**
     * This is the constructor of this class.
     * <p>
     * It assigns the passed in [MainActivity] instance (which
     * implements [OutputInterface]) to 'out'.
     */
    public Logic(OutputInterface out){
        mOut = out;
    }

    /**
     * This is the method that will (eventually) get called when the
     * on-screen button labeled 'Process...' is pressed.
     */
    public void process(int size) {
        // TODO -- add your code here
           int number_of_line=size*2+1;
        for(int i=1;i<=number_of_line;i++){

            if(i==1||i==number_of_line)
                mOut.println( top_or_bottom_line(size));
           else if (i<size+1)
                mOut.println("|"+line_above_mid(i,size)+"|");
           else if (i==size+1)
                mOut.println("|"+mid_line(size)+"|");
           else
                mOut.println("|"+line_below_mid(i,size)+"|");

       }

    }
    // TODO -- add any helper methods here
    public static String top_or_bottom_line(int size) {
        String str="+";
        int i=1;

        while(i<=2*size)
        {   str=str.concat("-");
          i++;
        }

        str=str.concat("+");

        return  str;

    }
    public static String line_above_mid(int i,int size) {
        String str="";
        int j=1;

        while(j<=size-i+1)
        {   str=str.concat(" ");
            j++;
        }

        str=str.concat("/");

        for(j=1;j<=i*2-4;j++) {
            if (i % 2 == 0)
                str = str.concat("=");
            else
                str = str.concat("-");
        }

        j=1;
        str=str.concat("\\");

        while(j<=size-i+1)
        {   str=str.concat(" ");
            j++;
        }

        return  str;}
    public static String mid_line(int size) {
        String str="<";
        int i=1;
        while(i<=2*size-2)
        {  if(size%2==0)
            str=str.concat("-");
          else
            str=str.concat("=");
            i++;
        }
        str=str.concat(">");

        return  str;}
    public static String  line_below_mid(int i,int size) {
           String str="";
           int j=1;

           while(j<=i-size-1)
           {   str=str.concat(" ");
               j++;
           }

           str=str.concat("\\");

           for(j=1;j<=(size*2-i)*2;j++) {
               if (i % 2 == 0)
                 str = str.concat("=");
               else
                 str = str.concat("-");
            }

               j=1;
                str=str.concat("/");

                 while(j<=i-size-1)
             {   str=str.concat(" ");
                  j++;
             }

             return  str;}
}